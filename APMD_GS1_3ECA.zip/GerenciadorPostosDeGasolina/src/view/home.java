package view;

import java.awt.EventQueue;
import model.*;
import model.enums.*;
import controller.*;
import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import net.miginfocom.swing.MigLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

public class home {

public JFrame home;
private CadastroController cadastroController;
private static RepositoryDB repository;
private JTextField txtNome;
private JTextField txtRua;
private JTextField txtBairro;
private JTextField txtCidade;
private JTextField txtEstado;
private JTextField txtAvaliacao;
private JTextField txtPrecoKWH;
private JLabel lblTipoPlug;

private JCheckBox cbxTipo1 = new JCheckBox("Tipo 1");;
private boolean cbxTipo1IsChecked = false;

private JCheckBox cbxTipo2 = new JCheckBox("Tipo 2");;
private boolean cbxTipo2IsChecked = false;

private JCheckBox cbxCSS2 = new JCheckBox("CSS2");;
private boolean cbxCSS2IsChecked = false;

private JCheckBox cbxCHA = new JCheckBox("CHAdeMO");;
private boolean cbxCHAIsChecked = false;

	public home(CadastroController cadastroControllerC, RepositoryDB repository) throws SQLException {
		cadastroController = cadastroControllerC;
		 cbxTipo1.setBounds(361, 349, 75, 23);
		 cbxTipo1.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				cbxTipo1IsChecked = !cbxTipo1IsChecked;
			}    
         
         });    
		 cbxTipo2.setBounds(472, 349, 85, 23);
		 
		 cbxTipo2.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					cbxTipo2IsChecked = !cbxTipo2IsChecked;
				}    
	         
	         });    
		 cbxCSS2.setBounds(361, 404, 75, 23);
		 
		 cbxCSS2.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					cbxCSS2IsChecked = !cbxCSS2IsChecked;
				}    
	         
	         });    
		 cbxCHA.setBounds(472, 404, 85, 23);
		 
		 cbxCHA.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					cbxCHAIsChecked = !cbxCHAIsChecked;
				}    
	         
	         });    

		this.repository = repository;
		initialize();
	}

	private void initialize() {
		home = new JFrame();
		home.setBackground(Color.DARK_GRAY);
		home.getContentPane().setBackground(Color.GRAY);
		home.getContentPane().setLayout(null);
		
		JLabel lbTitle = new JLabel("Cadastro de um novo posto");
		lbTitle.setBounds(190, 20, 250, 21);
		lbTitle.setFont(new Font("Tahoma", Font.BOLD, 17));
		lbTitle.setForeground(Color.BLACK);
		home.getContentPane().add(lbTitle);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(20, 61, 45, 17);
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNome.setForeground(Color.BLACK);
		home.getContentPane().add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(62, 61, 184, 20);
		home.getContentPane().add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblRua = new JLabel("Endereco");
		lblRua.setBounds(20, 98, 55, 17);
		lblRua.setForeground(Color.BLACK);
		lblRua.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblRua);
		
		txtRua = new JTextField();
		txtRua.setBounds(62, 98, 184, 20);
		txtRua.setColumns(10);
		home.getContentPane().add(txtRua);
		
		JLabel lblBairro = new JLabel("Bairro");
		lblBairro.setBounds(20, 135, 55, 17);
		lblBairro.setForeground(Color.BLACK);
		lblBairro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblBairro);
		
		txtBairro = new JTextField();
		txtBairro.setBounds(62, 135, 184, 20);
		txtBairro.setColumns(10);
		home.getContentPane().add(txtBairro);
		
		
		JLabel lblCidade = new JLabel("Cidade");
		lblCidade.setBounds(15, 172, 55, 17);
		lblCidade.setForeground(Color.BLACK);
		lblCidade.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblCidade);
		
		txtCidade = new JTextField();
		txtCidade.setBounds(62, 172, 184, 20);
		txtBairro.setColumns(10);
		home.getContentPane().add(txtCidade);
		
		JLabel lblEstado = new JLabel("Estado");
		lblEstado.setBounds(14, 207, 42, 17);
		lblEstado.setForeground(Color.BLACK);
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblEstado);
		
		txtEstado = new JTextField();
		txtEstado.setBounds(62, 207, 184, 20);
		txtCidade.setColumns(10);
		home.getContentPane().add(txtEstado);
		
		JLabel lblAvaliacao = new JLabel("Avalia\u00E7\u00E3o");
		lblAvaliacao.setBounds(299, 98, 74, 17);
		lblAvaliacao.setForeground(Color.BLACK);
		lblAvaliacao.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblAvaliacao);
		
		txtAvaliacao = new JTextField();
		txtAvaliacao.setBounds(377, 98, 146, 20);
		txtAvaliacao.setColumns(10);
		home.getContentPane().add(txtAvaliacao);
		
		JLabel lblPrecoKWH = new JLabel("Pre\u00E7o Kw/h");
		lblPrecoKWH.setBounds(299, 172, 97, 17);
		lblPrecoKWH.setForeground(Color.BLACK);
		lblPrecoKWH.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblPrecoKWH);
		
		txtPrecoKWH = new JTextField();
		txtPrecoKWH.setBounds(377, 172, 146, 20);
		home.getContentPane().add(txtPrecoKWH);
		txtPrecoKWH.setColumns(10);
		
		lblTipoPlug = new JLabel("Tipo de Plug");
		lblTipoPlug.setBounds(406, 325, 111, 17);
		lblTipoPlug.setForeground(Color.BLACK);
		lblTipoPlug.setFont(new Font("Tahoma", Font.PLAIN, 14));
		home.getContentPane().add(lblTipoPlug);
		home.getContentPane().add(cbxTipo1);
		home.getContentPane().add(cbxTipo2);
		home.getContentPane().add(cbxCSS2);
		home.getContentPane().add(cbxCHA);
		
		JButton btnCadastrar = new JButton("Cadastrar Posto");
		btnCadastrar.setBounds(95, 255, 150, 41);
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				ArrayList<tipoPlug> plugs = new ArrayList<tipoPlug>();
				
				if (cbxTipo1IsChecked) {
					plugs.add(tipoPlug.tipo1);
				}
				if (cbxTipo2IsChecked) {
					plugs.add(tipoPlug.tipo2);
				}
				if (cbxCSS2IsChecked) {
					plugs.add(tipoPlug.css2);
				}
				if (cbxCHAIsChecked) {
					plugs.add(tipoPlug.chademo);
				}
				
				Endereco enderecoCadastro = new Endereco(txtRua.getText(), 
												 txtBairro.getText(), 
												 txtCidade.getText(), 
												 txtEstado.getText());
				
				PostoDeGasolina novoPosto = new PostoDeGasolina(txtNome.getText(), enderecoCadastro, txtAvaliacao.getText(), plugs, txtPrecoKWH.getText());
				
				try {
					repository.inserirPosto(novoPosto);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnCadastrar.setBackground(Color.YELLOW);
		home.getContentPane().add(btnCadastrar);
		
		JButton btnTabela = new JButton("Tabela");
		btnTabela.setBounds(310, 212, 86, 45);
		btnTabela.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Tabela window = new Tabela(repository);
							window.frmTabela.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				
			}
		});
		btnTabela.setBackground(Color.YELLOW);
		home.getContentPane().add(btnTabela);
		
		JButton btnMapa = new JButton("Mapa");
		btnMapa.setBounds(418, 212, 97, 45);
		btnMapa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								Mapa window = new Mapa(repository);
								window.frame.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				
			}
		});
		btnMapa.setBackground(Color.YELLOW);
		home.getContentPane().add(btnMapa);
		
		
		home.setForeground(Color.WHITE);
		home.setTitle("Gerenciador postos de abastecimento");
		home.setBounds(100, 100, 599, 505);
		home.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
