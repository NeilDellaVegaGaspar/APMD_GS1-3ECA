package model.enums;

public enum tipoPlug {
	tipo1,
	tipo2,
	css2,
	chademo
}
